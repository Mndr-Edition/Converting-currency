const currency={
  RUB:0.11,
  USD:1,
  CEN:0.5
}

//связь
const reset=document.getElementById("btn-reset");
const h3=document.getElementById('h3');
const total=document.getElementById("total-out");
const text=document.getElementById("inp");
const USD=document.getElementById("btn-USD");
const RUB=document.getElementById("btn-RUB");
const CEN=document.getElementById("btn-CEN");
  let currentCurrency=null;
  let fromCurrency=null;
  let toCurrency=null;

//слушатели
USD.addEventListener('click', (event) => {
  currentCurrency = "USD";
  h3.innerHTML = `В какую валюту?`;
  
  if (fromCurrency === null) {
    fromCurrency = "USD"; 
  } else if (fromCurrency !== null && toCurrency === null) { 
    toCurrency = "USD"; 
  }
  
  if (fromCurrency !== null && toCurrency !== null) {
    USD.classList.add('hidden');
    RUB.classList.add('hidden');
    CEN.classList.add('hidden');
    h3.classList.add('hidden');
    total.classList.remove('hidden');
  }
});


RUB.addEventListener('click', (event)=>{
  currentCurrency="RUB";
  h3.innerHTML=`В какую валюту?`;
  if (fromCurrency === null) {
    fromCurrency = "RUB"; 
  } else if (fromCurrency !== null && toCurrency === null) { 
    toCurrency = "RUB"; 
  }
  
  if (fromCurrency !== null && toCurrency !== null) {
    USD.classList.add('hidden');
    RUB.classList.add('hidden');
    CEN.classList.add('hidden');
    h3.classList.add('hidden');
    total.classList.remove('hidden');
  }
});

CEN.addEventListener('click', (event)=>{
  currentCurrency="CEN";
  h3.innerHTML=`В какую валюту?`;
  if (fromCurrency === null) {
    fromCurrency = "CEN"; 
  } else if (fromCurrency !== null && toCurrency === null) { 
    toCurrency = "CEN"; 
  }
  
  if (fromCurrency !== null && toCurrency !== null) {
    USD.classList.add('hidden');
    RUB.classList.add('hidden');
    CEN.classList.add('hidden');
    h3.classList.add('hidden');
    total.classList.remove('hidden');
  }
});

text.addEventListener('input', (event)=>{
  if(fromCurrency!==null&&toCurrency!==null){
  const user= Number(event.target.value);
  const toCurrent=currency[toCurrency];
  const fromCurrent=currency[fromCurrency];
  const result = (user * fromCurrent) / toCurrent;
  total.innerHTML=`${result.toFixed(2)}`;
  }
});

reset.addEventListener('click', (event)=>{
  USD.classList.remove("hidden");
  RUB.classList.remove("hidden");
  CEN.classList.remove("hidden");
  fromCurrency=null;
  toCurrency=null;
  text.value="";
  total.innerHTML="";
});
